import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Random;

public class Spedizione {
	private String descrizione;
	private LocalDate data;
	private String mittente;
	private String destinatario;
	private int codiceSpedizione;
	
	
	public Spedizione(String descrizione, LocalDate localDate, String mittente, String destinatario) {
		this.descrizione = descrizione;
		this.data = localDate;
		this.mittente = mittente;
		this.destinatario = destinatario;
	}

	public int GeneraCodice() {
		Random rand = new Random();
		int cod = rand.nextInt(100);
		return cod;
	}
	
	public int getCodiceSpedizione() {
		return codiceSpedizione;
	}


	public void setCodiceSpedizione(int codiceSpedizione) {
		this.codiceSpedizione = codiceSpedizione;
	}


	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public LocalDate getData() {
		return data;
	}

	public void setData(LocalDate data) {
		this.data = data;
	}

	public String toString() {
		return "Spedizione: " + descrizione + ", data consegna:" + data + ", mittente:" + mittente
				+ ", destinatario" + destinatario;
	}
	
	

}
