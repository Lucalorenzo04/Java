import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		Corriere corriere = new Corriere();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner input = new Scanner(System.in);
		int scelta;
		do {
			System.out.println("------------MENU------------");
			System.out.println("(1) Memorizza cliente");
			System.out.println("(2) Memorizza spedizione");
			System.out.println("(3) Visualizza dati spedizione ");
			System.out.println("(4) Stampa elenco donazioni");
			System.out.println("(0) Esci");
			String nome = null;
			String citta = null;
			String nTel = null;
			String codFisc = null;
			int codice;
			scelta = input.nextInt();
			input.nextLine();
			switch (scelta) {
			case 1: {
				System.out.print("Denominazione: ");
				nome = input.nextLine();
				System.out.print("citta:");
				citta = input.nextLine();
				do {
					System.out.print("numero di telefono:");
					nTel = input.nextLine();
				} while (nTel.length() > 10 || nTel.length() < 10);
					
				Cliente c = new Cliente(nome, citta, nTel);
				System.out.print("Codice fiscale:");
				codFisc = input.nextLine();
				corriere.memorizzaCliente(codFisc, c);
				System.out.println(corriere.clienti);
				break;
			}
			case 2: {
				System.out.print("Descrizione: ");
				nome = input.nextLine();
				System.out.print("Mittente:");
				citta = input.nextLine();
				System.out.print("Destinatario");
				nTel = input.nextLine();

				int giorno;
				do {
					System.out.println("-----------------Data della consegna--------------");
					System.out.println("Giorno: ");
					giorno = input.nextInt();
					if (giorno < 0 || giorno > 31) {
						System.out.println("Giorno non valido... ");
					}
				} while (giorno < 0 || giorno > 31);
				int mese;
				do {
					System.out.print("Mese: ");
					mese = input.nextInt();

					if (mese < 0 || mese > 12) {
						System.out.println("Mese non valido... ");
					}
				} while (mese < 0 || mese > 12);

				int anno;
				do {
					System.out.print("Anno: ");
					anno = input.nextInt();
					if (anno < 2020 || anno > 2030) {
						System.out.println("Anno non valido... ");
					}
				} while (anno < 0 || anno > 2022);

				Spedizione s = new Spedizione(nome, LocalDate.of(anno, mese, giorno), citta, nTel);
				s.setCodiceSpedizione(s.GeneraCodice());
				corriere.memorizzaSpedizione(s.getCodiceSpedizione(), s);
				System.out.println("Codice Generato alla consegna:" + s.getCodiceSpedizione());
				System.out.println(corriere.spedizioni);
				break;
			}
			case 3: {
				System.out.print("Codice spedizione:");
				codice = input.nextInt();
				corriere.cercaStampaSpedizione(codice);
				break;
			}
			case 4: {
				break;
			}

			}
		} while (scelta != 0);

		input.close();
	}

}
