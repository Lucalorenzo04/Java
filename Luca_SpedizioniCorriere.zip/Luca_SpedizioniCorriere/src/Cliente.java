import java.util.TreeMap;

public class Cliente {
	private String denominazione;
	private String citt�;
	private String nTel;
	
	public Cliente(String denominazione, String citt�, String nTel) {
		this.denominazione = denominazione;
		this.citt� = citt�;
		this.nTel = nTel;
	}

	public String getDenominazione() {
		return denominazione;
	}

	public void setDenominazione(String denominazione) {
		this.denominazione = denominazione;
	}

	public String getCitt�() {
		return citt�;
	}

	public void setCitt�(String citt�) {
		this.citt� = citt�;
	}

	public String getnTel() {
		return nTel;
	}

	public void setnTel(String nTel) {
		this.nTel = nTel;
	}
	
	

}
