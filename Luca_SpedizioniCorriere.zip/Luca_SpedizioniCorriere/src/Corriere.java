import java.util.HashMap;
import java.util.Random;
import java.util.TreeMap;

public class Corriere {

	public Corriere() {
	}

	HashMap<Integer, Spedizione> spedizioni = new HashMap<>();
	TreeMap<String, Cliente> clienti = new TreeMap<String, Cliente>();

	public void memorizzaSpedizione(int cod, Spedizione s) {
		this.spedizioni.put(cod, s);
	}

	public void memorizzaCliente(String codF, Cliente c) {
		clienti.put(codF, c);
	}

	public void cercaStampaSpedizione(int cod) {
		if (spedizioni.containsValue(cod)== true) {
			System.out.println(spedizioni.get(cod).toString());
		} else {
			System.out.println("Spedizione non presente");
		}
	}
}
