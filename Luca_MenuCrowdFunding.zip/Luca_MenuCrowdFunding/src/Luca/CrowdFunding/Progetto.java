package Luca.CrowdFunding;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

public class Progetto {

	private String titolo;
	private String descrizione;
	private Double budgetFin;
	private LocalDate scadenza;

	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	private List<Donazione> donazioni = new ArrayList<>();

	public Progetto(String titolo, String descrizione, Double budgetFin, LocalDate scadenza) {
		super();
		this.titolo = titolo;
		this.descrizione = descrizione;
		this.budgetFin = budgetFin;
		this.scadenza = scadenza;
	}

	public Progetto(Progetto p) {
		super();
		this.titolo = p.getTitolo();
		this.descrizione = p.getDescrizione();
		this.budgetFin = p.getBudgetFin();
		this.scadenza = p.getScadenza();
	}

	public String getTitolo() {
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public Double getBudgetFin() {
		return budgetFin;
	}

	public void setBudgetFin(Double budgetFin) {
		this.budgetFin = budgetFin;
	}

	public LocalDate getScadenza() {
		return scadenza;
	}

	public void setScadenza(LocalDate scadenza) {
		this.scadenza = scadenza;
	}

	public List<Donazione> getDonazioni() {
		return donazioni;
	}

	public void setDonazioni(List<Donazione> donazioni) {
		this.donazioni = donazioni;
	}

	public void aggiungiDonazione(Donazione d) {
		for (Donazione donazione : donazioni) {
			if (d.getNomeDonatore().equalsIgnoreCase(donazione.getNomeDonatore())) {
				return;
			}
		}
		donazioni.add(d);
	}

	public Donazione ricercaPerNome(String n) {
		for (Donazione donazione : donazioni) {
			if (n.equalsIgnoreCase(donazione.getNomeDonatore())) {
				return donazione;
			}
		}
		return null;
	}

	public void eliminaPerNome(String n) {
		donazioni.remove(ricercaPerNome(n));
	}

	public List<Donazione> ricercaERestituisci(String c) {
		List<Donazione> array = new ArrayList<>();

		for (Donazione donazione : donazioni) {
			if (c.equalsIgnoreCase(donazione.getTipo())) {
				array.add(donazione);
			}
		}

		for (int i = 0; i < array.size() - 1; i++) {
			Donazione app;
			if (array.get(i).getImporto() < array.get(i + 1).getImporto()) {
				app = array.get(i);
				array.set(i, array.get(i + 1));
				array.set(i + 1, app);
			}
		}
		return array;
	}

	public long giorniAllaScadenza() {
		LocalDate oggi = LocalDate.now();
		return ChronoUnit.DAYS.between(oggi, this.scadenza);
	}

	public int numeroImporti() {
		return donazioni.size();
	}

	public double totaleImporti() {
		double tot = 0;
		for (Donazione donazione : donazioni) {
			tot += donazione.getImporto();
		}
		return tot;
	}

	public Donazione migliorDonatore() {
		Donazione don = null;
		double max = 0;
		for (Donazione donazione : donazioni) {
			if (donazione.getImporto() > max) {
				don = donazione;
				max = donazione.getImporto();
			}
		}
		return don;
	}

	public int percentuale() {
		return (int) ((totaleImporti() * 100) / this.budgetFin);
	}

	public void stampaLista() {
		for (Donazione donazione : donazioni) {
			System.out.println(donazione.toString());
		}
	}

	public void salva(List<Donazione> donazioni)  {
		ObjectOutputStream oos = null;
		try {
			// APRO IL FILE IN SCRITTURA
			oos = new ObjectOutputStream(new FileOutputStream("donazioni.bin"));
			// SERIALIZZO L'OGGETTO lista di studenti
			oos.writeObject(donazioni);
			oos.close();
			System.out.println("Dati salvati nel file donazioni.bin");
		} catch (IOException e) {
			System.out.println("Errore nella scrittura del file");
		}
	}

	public void carica() {
		ObjectInputStream ois = null;
		try {
			ois = new ObjectInputStream(new FileInputStream("donazioni.bin"));
			this.donazioni = (ArrayList<Donazione>) ois.readObject();
			ois.close();
			System.out.println("Lettura dati dal file donazioni.bin");
		} catch (IOException | ClassNotFoundException e) {
			System.out.println("Errore nella lettura da file");
		}
	}

	public String toString() {
		return "\t" + "---" + this.titolo + "---" + "\n" + "Descrizione: " + this.descrizione + "\n" + "Scadenza: "
				+ this.scadenza.format(formatter) + "\n" + "Obbiettivo: " + this.budgetFin + "\n" + "Numero donazioni: "
				+ numeroImporti() + "\n" + "Totale donazioni: " + totaleImporti() + "\n" + "Miglior donatore: "
				+ migliorDonatore().getNomeDonatore() + ", importo: " + migliorDonatore().getImporto() + "\n"
				+ "Percentuale completamento obbiettivo: " + percentuale() + "%";
	}

}
