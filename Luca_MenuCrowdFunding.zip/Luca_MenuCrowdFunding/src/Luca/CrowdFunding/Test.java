package Luca.CrowdFunding;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.io.Serializable;

public class Test {

	public static void main(String[] args) {

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner input = new Scanner(System.in);

		Progetto p = new Progetto("Bambini in Africa",
				"Raccolta fondi atto a fornire materie prime ai bambini in Africa", 10000.00,
				LocalDate.parse("15/04/2022", formatter));
		p.carica();
		int scelta;
		do {
			System.out.println("------------MENU------------");
			System.out.println("(1) Crea e inserisci donazione");
			System.out.println("(2) Cancella donazione");
			System.out.println("(3) Stampa riepilogo progetto ");
			System.out.println("(4) Stampa elenco donazioni");
			System.out.println("(0) Esci");
			String data = null;
			String nome = null;
			String tipo = null;
			int importo = 0;
			scelta = input.nextInt();
			input.nextLine();
			switch (scelta) {
			case 1: {
				System.out.print("Nome: ");
				nome = input.nextLine();
				System.out.print("tipo donatore 'F' o 'G': ");
				tipo = input.nextLine();

				do {
					System.out.print("importo: ");
					importo = input.nextInt();
					if (importo < 0) {
						System.out.println("L'importo non pu� essere negativo... ");
					}
				} while (importo < 0);

				System.out.println("Data Donazione");

				int giorno;
				do {
					System.out.println("Giorno: ");
					giorno = input.nextInt();
					if (giorno < 0 || giorno > 31) {
						System.out.println("Giorno non valido... ");
					}
				} while (giorno < 0 || giorno > 31);
				System.out.print("Mese: ");
				int mese;
				do {
					System.out.print("Mese: ");
					mese = input.nextInt();

					if (mese < 0 || mese > 12) {
						System.out.println("Mese non valido... ");
					}
				} while (mese < 0 || mese > 12);

				int anno;
				do {
					System.out.print("Anno: ");
					anno = input.nextInt();
					if (anno < 2020 || anno > 2022) {
						System.out.println("Anno non valido... ");
					}
				} while (anno < 0 || anno > 2022);
				Donazione d = new Donazione(nome, tipo, importo, LocalDate.of(anno, mese, giorno));
				p.aggiungiDonazione(d);
				System.out.println("DONAZIONE AGGIUNTA CON SUCCESSO!");
				break;
			}
			case 2: {
				System.out.println("Nome della donazione da cancellare: ");
				nome = input.nextLine();
				p.eliminaPerNome(nome);
				break;
			}
			case 3: {
				System.out.println(p.toString());

				break;
			}
			case 4: {
				p.stampaLista();
				break;
			}

			}
		} while (scelta != 0);

		input.close();
		p.salva(p.getDonazioni());
	}

}
