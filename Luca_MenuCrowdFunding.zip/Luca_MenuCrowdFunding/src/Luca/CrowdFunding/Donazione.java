package Luca.CrowdFunding;

import java.io.Serializable;
import java.time.LocalDate;

public class Donazione implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String nomeDonatore;
	private String tipo;
	private double importo;
	private LocalDate dataDonazione;
	
	public Donazione(String nomeDonatore, String tipo, double importo, LocalDate dataDonazione) {
		super();
		this.nomeDonatore = nomeDonatore;
		this.tipo = tipo;
		this.importo = importo;
		this.dataDonazione = dataDonazione;
	}
	
	public Donazione(Donazione d) {
		super();
		this.nomeDonatore = d.getNomeDonatore();
		this.tipo = d.getTipo();
		this.importo = d.getImporto();
		this.dataDonazione = d.getDataDonazione();
	}

	public String getNomeDonatore() {
		return nomeDonatore;
	}

	public void setNomeDonatore(String nomeDonatore) {
		this.nomeDonatore = nomeDonatore;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public double getImporto() {
		return importo;
	}

	public void setImporto(double importo) {
		this.importo = importo;
	}

	public LocalDate getDataDonazione() {
		return dataDonazione;
	}

	public void setDataDonazione(LocalDate dataDonazione) {
		this.dataDonazione = dataDonazione;
	}

	@Override
	public String toString() {
		return "Nome donatore: " + nomeDonatore + ", tipo: " + tipo + ", importo: " + importo
				+ ", data donazione: " + dataDonazione;
	}	
	
	

}
